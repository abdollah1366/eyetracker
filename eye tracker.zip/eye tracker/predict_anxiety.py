import cv2
import time
import numpy as np
import random
import matplotlib.pyplot as plt

# -------------------------------
# مسیر تصاویر محرک (stimuli)
image_paths = [f"stimuli/{i}.jpg" for i in range(1, 10)]  # تصاویر در پوشه stimuli
duration_per_image = 20  # زمان نمایش هر تصویر (ثانیه)

# داده‌های مصنوعی اضطراب (برای مقایسه)
fake_anxiety_data = [0.82, 0.88, 0.80, 0.85, 0.90]          # افراد مضطرب
fake_neurotypical_data = [0.10, 0.12, 0.08, 0.14, 0.09]     # افراد نرمال
heatmap_coords = []

# -------------------------------
# بررسی اینکه نگاه به مرکز بوده یا نه (نشانه تمرکز و آرامش)
def is_fixated_looking(eye_pos, frame_shape):
    h, w = frame_shape[:2]
    x, y = eye_pos
    return abs(x - w // 2) < w // 8 and abs(y - h // 2) < h // 8

# -------------------------------
# شبیه‌سازی ردیابی نگاه با مختصات تصادفی
def simulate_eye_tracking():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("وب‌کم پیدا نشد.")
        return [], None

    attention_scores = []
    frame_shape = None

    cv2.namedWindow("Stimulus", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("Stimulus", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    for img_path in image_paths:
        img = cv2.imread(img_path)
        if img is None:
            print(f"تصویر پیدا نشد: {img_path}")
            continue

        screen_w = 1920
        screen_h = 1080
        img_resized = cv2.resize(img, (screen_w, screen_h))
        start_img_time = time.time()

        while time.time() - start_img_time < duration_per_image:
            ret, frame = cap.read()
            if not ret:
                break

            frame_shape = frame.shape
            eye_x = random.randint(0, frame.shape[1] - 1)
            eye_y = random.randint(0, frame.shape[0] - 1)
            heatmap_coords.append((eye_x, eye_y))

            scattered_looking = not is_fixated_looking((eye_x, eye_y), frame.shape)
            attention_scores.append(1 if scattered_looking else 0)

            cv2.imshow("Stimulus", img_resized)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()
    return attention_scores, frame_shape

# -------------------------------
# محاسبه احتمال اضطراب
def calculate_anxiety_probability(scores):
    deviation_ratio = sum(scores) / len(scores)
    anxiety_avg = np.mean(fake_anxiety_data)
    normal_avg = np.mean(fake_neurotypical_data)

    dist_anxiety = abs(deviation_ratio - anxiety_avg)
    dist_normal = abs(deviation_ratio - normal_avg)

    probability = 100 * (1 - dist_anxiety / (dist_anxiety + dist_normal + 1e-6))
    return round(probability, 2), deviation_ratio

# -------------------------------
# ترسیم نمودار نتایج
def plot_anxiety_result(prob, deviation_ratio):
    labels = ['Your Score', 'Anxiety Mean', 'Normal Mean']
    values = [deviation_ratio, np.mean(fake_anxiety_data), np.mean(fake_neurotypical_data)]
    colors = ['orange', 'red', 'green']

    plt.figure(figsize=(8, 5))
    plt.bar(labels, values, color=colors)
    plt.title(f"Estimated Probability of Anxiety: {prob}%", fontsize=14)
    plt.ylabel("Scattered Gaze Ratio")
    plt.ylim(0, 1)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()

# -------------------------------
# ترسیم هیت‌مپ نقاط نگاه
def show_heatmap(coords, frame_shape):
    if not coords or frame_shape is None:
        print("مختصات کافی وجود ندارد.")
        return

    h, w = frame_shape[:2]
    heatmap = np.zeros((h, w), dtype=np.float32)

    for (x, y) in coords:
        if 0 <= y < h and 0 <= x < w:
            heatmap[y, x] += 1

    heatmap = cv2.GaussianBlur(heatmap, (101, 101), 0)
    heatmap = np.clip(heatmap / np.max(heatmap), 0, 1)

    plt.figure(figsize=(10, 5))
    plt.imshow(heatmap, cmap='hot')
    plt.title("Eye Gaze Heatmap")
    plt.axis('off')
    plt.show()

# -------------------------------
# اجرای برنامه اصلی
if __name__ == "__main__":
    print("شروع تست تخمین اضطراب...\nلطفاً به‌صورت طبیعی به صفحه نگاه کنید.")

    scores, shape = simulate_eye_tracking()
    if not scores:
        print("تست با شکست مواجه شد. داده‌ای از نگاه ثبت نشد.")
    else:
        prob, ratio = calculate_anxiety_probability(scores)
        print(f"\nاحتمال تخمینی اضطراب: {prob}%")
        plot_anxiety_result(prob, ratio)
        show_heatmap(heatmap_coords, shape)
