import cv2
import numpy as np
import mediapipe as mp
import time


# Screen dimensions
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

# Calibration points on the screen
calibration_points = [
    (100, 100),  # top-left
    (SCREEN_WIDTH - 100, 100),  # top-right
    (SCREEN_WIDTH - 100, SCREEN_HEIGHT - 100),  # bottom-right
    (100, SCREEN_HEIGHT - 100),  # bottom-left
    (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)  # center
]

# Initialize MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(max_num_faces=1, refine_landmarks=True)

def show_dot(x, y):
    img = np.zeros((SCREEN_HEIGHT, SCREEN_WIDTH, 3), dtype=np.uint8)
    cv2.circle(img, (x, y), 20, (0, 255, 0), -1)
    cv2.imshow("Calibration", img)

def get_eye_center(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)
    if results.multi_face_landmarks:
        landmarks = results.multi_face_landmarks[0].landmark
        eye_indices = [33, 133, 160, 159, 158, 144, 153, 154, 155]  # right eye
        h, w, _ = frame.shape
        xs = [landmarks[i].x * w for i in eye_indices]
        ys = [landmarks[i].y * h for i in eye_indices]
        return (int(np.mean(xs)), int(np.mean(ys)))
    return None

def calibrate_with_mediapipe_auto():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Camera not found.")
        return None

    cv2.namedWindow("Calibration", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("Calibration", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    screen_coords = []
    eye_coords = []

    for (x, y) in calibration_points:
        print(f"Calibrating point: ({x}, {y})")
        collected = []
        start_time = time.time()

        while time.time() - start_time < 4:  # 4 seconds per point
            ret, frame = cap.read()
            if not ret:
                continue

            show_dot(x, y)
            eye_center = get_eye_center(frame)
            if eye_center:
                collected.append(eye_center)

            if cv2.waitKey(1) & 0xFF == 27:
                cap.release()
                cv2.destroyAllWindows()
                return None

        if collected:
            avg_eye = np.mean(collected, axis=0)
            eye_coords.append(avg_eye)
            screen_coords.append([x, y])
        else:
            print("Failed to detect eye for this point.")

    cap.release()
    cv2.destroyAllWindows()

    if len(eye_coords) < 3:
        print("Not enough valid points collected for homography.")
        return None

    eye_coords = np.array(eye_coords, dtype=np.float32)
    screen_coords = np.array(screen_coords, dtype=np.float32)
    matrix, _ = cv2.findHomography(eye_coords, screen_coords)

    if matrix is None or matrix.shape != (3, 3):
        print("❌ Homography matrix creation failed.")
        return None

    print("✅ Calibration complete.")
    return matrix

def map_eye_to_screen(eye_point, matrix):
    if matrix is None or matrix.shape != (3, 3):
        raise ValueError("Invalid homography matrix.")
    src = np.array([[eye_point]], dtype=np.float32)
    dst = cv2.perspectiveTransform(src[None, :, :], matrix)
    return tuple(dst[0][0])

# Run calibration and test mapping
if __name__ == "__main__":
    matrix = calibrate_with_mediapipe_auto()
    if matrix is not None:
        test_point = (320, 240)
        try:
            mapped = map_eye_to_screen(test_point, matrix)
            print("Example mapped point:", mapped)
        except Exception as e:
            print("Mapping failed:", e)
np.save("calibration_matrix.npy", matrix)
print("✅ Matrix saved as calibration_matrix.npy")
