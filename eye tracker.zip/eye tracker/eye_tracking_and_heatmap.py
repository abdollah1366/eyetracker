import cv2
import dlib
import numpy as np
import csv
import os
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
sys.stdout.reconfigure(encoding='utf-8')

# ----------- تنظیمات ----------- #
OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)
csv_path = os.path.join(OUTPUT_DIR, "pupil_positions.csv")

# ----------- تشخیص دوربین ----------- #
def find_available_camera():
    for i in range(5):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            cap.release()
            return i
    return -1

camera_index = find_available_camera()
if camera_index == -1:
    print("❌ No camera found.")
    exit()

cap = cv2.VideoCapture(camera_index)
print(f"✅ Camera detected at port {camera_index}")

# ----------- مدل dlib ----------- #
predictor_path = "shape_predictor_68_face_landmarks.dat"
if not os.path.exists(predictor_path):
    print("❌ shape_predictor_68_face_landmarks.dat not found.")
    exit()

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(predictor_path)
pupil_positions = []

# ----------- تشخیص مردمک ----------- #
def detect_pupil(eye_points, gray):
    eye_region = np.array(eye_points, np.int32)
    min_x = np.min(eye_region[:, 0])
    max_x = np.max(eye_region[:, 0])
    min_y = np.min(eye_region[:, 1])
    max_y = np.max(eye_region[:, 1])
    eye_img = gray[min_y:max_y, min_x:max_x]
    if eye_img.size == 0:
        return None
    _, threshold_eye = cv2.threshold(eye_img, 40, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(threshold_eye, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=lambda x: cv2.contourArea(x), reverse=True)
    if contours:
        M = cv2.moments(contours[0])
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            return (cX + min_x, cY + min_y)
    return None

# ----------- ردیابی چشم ----------- #
print("🎥 Fullscreen started. Press ESC to exit eye tracking...")
cv2.namedWindow("Eye Tracking", cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty("Eye Tracking", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Failed to read frame.")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)
    left_pupil, right_pupil = None, None

    for face in faces:
        landmarks = predictor(gray, face)
        left_eye_points = [(landmarks.part(i).x, landmarks.part(i).y) for i in range(36, 42)]
        right_eye_points = [(landmarks.part(i).x, landmarks.part(i).y) for i in range(42, 48)]
        left_pupil = detect_pupil(left_eye_points, gray)
        right_pupil = detect_pupil(right_eye_points, gray)

        if left_pupil:
            cv2.circle(frame, left_pupil, 3, (0, 255, 0), -1)
        if right_pupil:
            cv2.circle(frame, right_pupil, 3, (0, 255, 0), -1)

    # راهنمای کاربر
    cv2.putText(frame, "Press ESC to exit eye tracking", (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    pupil_positions.append([
        left_pupil[0] if left_pupil else -1,
        left_pupil[1] if left_pupil else -1,
        right_pupil[0] if right_pupil else -1,
        right_pupil[1] if right_pupil else -1
    ])

    cv2.imshow("Eye Tracking", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()

# ----------- ذخیره CSV ----------- #
with open(csv_path, "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["left_x", "left_y", "right_x", "right_y"])
    writer.writerows(pupil_positions)

print(f"✅ Pupil positions saved in {csv_path}")

# ----------- Heatmap 3D ----------- #
x_list = []
y_list = []

with open(csv_path, 'r') as f:
    reader = csv.reader(f)
    next(reader)
    for row in reader:
        for i in [0, 2]:
            try:
                x = int(row[i])
                y = int(row[i+1])
                if x != -1 and y != -1:
                    x_list.append(x)
                    y_list.append(y)
            except:
                continue

if len(x_list) == 0 or len(y_list) == 0:
    print("⚠️ No valid pupil coordinates for 3D heatmap.")
else:
    heatmap, xedges, yedges = np.histogram2d(x_list, y_list, bins=(50, 50))
    x_pos, y_pos = np.meshgrid(xedges[:-1], yedges[:-1])
    x_pos = x_pos.ravel()
    y_pos = y_pos.ravel()
    z_pos = np.zeros_like(x_pos)
    dx = dy = (xedges[1] - xedges[0])
    dz = heatmap.T.ravel()

    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.bar3d(x_pos, y_pos, z_pos, dx, dy, dz, shade=True, color='red')
    ax.set_title("3D Pupil Positions Heatmap")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Frequency")
    plt.tight_layout()

    heatmap_path = os.path.join(OUTPUT_DIR, "pupil_heatmap_3d.png")
    plt.savefig(heatmap_path, dpi=200)
    plt.show()
    print(f"✅ 3D Heatmap image saved as {heatmap_path}")
