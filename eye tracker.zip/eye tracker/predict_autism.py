import cv2
import time
import numpy as np
import random
import matplotlib.pyplot as plt

# -------------------------------
# مسیر تصاویر محرک (stimuli)
image_paths = [f"stimuli/{i}.jpg" for i in range(1, 10)]
duration_per_image = 20

# داده‌های مصنوعی (قابل جایگزینی با داده واقعی)
fake_autism_data = [0.75, 0.82, 0.70, 0.78, 0.80]
fake_neurotypical_data = [0.10, 0.08, 0.15, 0.12, 0.18]
heatmap_coords = []

# -------------------------------
# بررسی اینکه آیا نگاه در ناحیه اجتماعی (مثلاً مرکز صورت) بوده یا نه
def is_social_area_looking(eye_pos, frame_shape):
    h, w = frame_shape[:2]
    x, y = eye_pos
    return abs(x - w // 2) < w // 8 and abs(y - h // 2) < h // 8

# -------------------------------
# شبیه‌سازی ردیابی نگاه (با مختصات تصادفی)
def simulate_eye_tracking():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Webcam not detected.")
        return [], None

    attention_scores = []
    frame_shape = None

    cv2.namedWindow("Stimulus", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("Stimulus", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    for img_path in image_paths:
        img = cv2.imread(img_path)
        if img is None:
            print(f"Image not found: {img_path}")
            continue

        screen_w = 1920
        screen_h = 1080
        img_resized = cv2.resize(img, (screen_w, screen_h))
        start_img_time = time.time()

        while time.time() - start_img_time < duration_per_image:
            ret, frame = cap.read()
            if not ret:
                break

            frame_shape = frame.shape
            eye_x = random.randint(0, frame.shape[1] - 1)
            eye_y = random.randint(0, frame.shape[0] - 1)
            heatmap_coords.append((eye_x, eye_y))

            social_looking = is_social_area_looking((eye_x, eye_y), frame.shape)
            attention_scores.append(0 if social_looking else 1)

            cv2.imshow("Stimulus", img_resized)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()
    return attention_scores, frame_shape

# -------------------------------
# محاسبه احتمال اوتیسم بر اساس نمره توجه اجتماعی
def calculate_autism_probability(scores):
    deviation_ratio = sum(scores) / len(scores)
    fake_autism_avg = np.mean(fake_autism_data)
    fake_neurotypical_avg = np.mean(fake_neurotypical_data)

    dist_autism = abs(deviation_ratio - fake_autism_avg)
    dist_neurotypical = abs(deviation_ratio - fake_neurotypical_avg)

    probability = 100 * (1 - dist_autism / (dist_autism + dist_neurotypical + 1e-6))
    return round(probability, 2), deviation_ratio

# -------------------------------
# ترسیم نمودار میله‌ای نتایج
def plot_autism_result(prob, deviation_ratio):
    labels = ['Predicted Score', 'Autism Mean', 'Neurotypical Mean']
    values = [deviation_ratio, np.mean(fake_autism_data), np.mean(fake_neurotypical_data)]
    colors = ['orange', 'blue', 'green']

    plt.figure(figsize=(8, 5))
    plt.bar(labels, values, color=colors)
    plt.title(f"Estimated Probability of Autism: {prob}%", fontsize=14)
    plt.ylabel("Social Gaze Deviation Ratio")
    plt.ylim(0, 1)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()

# -------------------------------
# ترسیم هیت‌مپ نقاط نگاه
def show_heatmap(coords, frame_shape):
    if not coords or frame_shape is None:
        print("No coordinates or invalid frame shape.")
        return

    h, w = frame_shape[:2]
    heatmap = np.zeros((h, w), dtype=np.float32)

    for (x, y) in coords:
        if 0 <= y < h and 0 <= x < w:
            heatmap[y, x] += 1

    heatmap = cv2.GaussianBlur(heatmap, (101, 101), 0)
    heatmap = np.clip(heatmap / np.max(heatmap), 0, 1)

    plt.figure(figsize=(10, 5))
    plt.imshow(heatmap, cmap='jet')
    plt.title("Mean Eye Gaze Heatmap")
    plt.axis('off')
    plt.show()

# -------------------------------
# اجرای برنامه اصلی
if __name__ == "__main__":
    print("Starting Autism Prediction Test...\nPlease look at the screen naturally.")

    scores, shape = simulate_eye_tracking()
    if not scores:
        print("Test failed. No eye tracking data.")
    else:
        prob, ratio = calculate_autism_probability(scores)
        print(f"\nEstimated Probability of Autism: {prob}%")
        plot_autism_result(prob, ratio)
        show_heatmap(heatmap_coords, shape)
