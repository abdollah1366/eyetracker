import cv2
import os
import sys
import csv
import time
import math
import mediapipe as mp

def euclidean(p1, p2, w, h):
    return math.sqrt(((p1.x - p2.x) * w) ** 2 + ((p1.y - p2.y) * h) ** 2)

if len(sys.argv) < 3:
    print("Usage: record_eye_data.py <client_id> <disease>")
    sys.exit(1)

client_id = sys.argv[1]
disease = sys.argv[2].lower().replace("'", "").replace(" ", "_")
stimuli_folder = os.path.join("stimuli", disease)
output_folder = "eye_data"
os.makedirs(output_folder, exist_ok=True)

image_files = sorted([
    os.path.join(stimuli_folder, f) for f in os.listdir(stimuli_folder)
    if f.lower().endswith(('.jpg', '.jpeg', '.png'))
])

if not image_files:
    print(f"No images found in {stimuli_folder}")
    sys.exit(1)

output_file = os.path.join(output_folder, f"client_{client_id}_{disease}.csv")

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Webcam not found")
    sys.exit(1)

print(f"📷 Recording gaze data for client {client_id}, disorder: {disease}")

show_webcam = False  # وضعیت نمایش وب‌کم

cv2.namedWindow("Eye Tracking Fullscreen", cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty("Eye Tracking Fullscreen", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

with open(output_file, "w", newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow([
        'timestamp', 'stimulus',
        'left_eye_x', 'left_eye_y', 'right_eye_x', 'right_eye_y',
        'left_pupil_diameter', 'right_pupil_diameter'
    ])

    for image_path in image_files:
        stimulus = cv2.imread(image_path)
        if stimulus is None:
            continue

        # تمام‌صفحه نمایش داده شود
        screen_w = 1920
        screen_h = 1080
        stimulus = cv2.resize(stimulus, (screen_w, screen_h))
        stimulus_name = os.path.basename(image_path)

        start_time = time.time()
        duration = 10  # 10 ثانیه

        while time.time() - start_time < duration:
            ret, frame = cap.read()
            if not ret:
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb)

            h, w = frame.shape[:2]
            left_eye_x = left_eye_y = right_eye_x = right_eye_y = None
            left_diameter = right_diameter = None

            if results.multi_face_landmarks:
                landmarks = results.multi_face_landmarks[0].landmark

                left = landmarks[469]
                right = landmarks[474]
                left_eye_x, left_eye_y = int(left.x * w), int(left.y * h)
                right_eye_x, right_eye_y = int(right.x * w), int(right.y * h)

                left_diameter = euclidean(landmarks[468], landmarks[470], w, h)
                right_diameter = euclidean(landmarks[473], landmarks[475], w, h)

                # Draw landmarks
                cv2.circle(frame, (left_eye_x, left_eye_y), 5, (255, 0, 0), -1)
                cv2.circle(frame, (right_eye_x, right_eye_y), 5, (0, 255, 0), -1)

                writer.writerow([
                    time.time(), stimulus_name,
                    left_eye_x, left_eye_y,
                    right_eye_x, right_eye_y,
                    round(left_diameter, 2), round(right_diameter, 2)
                ])

            # کپی تصویر محرک برای رسم تصویر مراجع
            display_image = stimulus.copy()

            if show_webcam:
                small_cam = cv2.resize(frame, (320, 240))
                x_offset = screen_w - 340  # فاصله از سمت راست
                y_offset = 40  # فاصله از بالا

                display_image[y_offset:y_offset+240, x_offset:x_offset+320] = small_cam

            cv2.imshow("Eye Tracking Fullscreen", display_image)

            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                print("🛑 ESC pressed. Exiting early...")
                cap.release()
                cv2.destroyAllWindows()
                face_mesh.close()
                sys.exit(0)
            elif key == ord('v'):
                show_webcam = not show_webcam

cap.release()
cv2.destroyAllWindows()
face_mesh.close()
print(f"✅ Data saved to: {output_file}")
