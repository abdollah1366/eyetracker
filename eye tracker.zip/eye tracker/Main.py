import sys
import subprocess
import sqlite3
from PyQt5.QtWidgets import (
    QApplication, QLabel, QWidget, QPushButton, QVBoxLayout,
    QHBoxLayout, QComboBox, QStackedLayout, QListWidget, QMessageBox,
    QInputDialog
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPixmap, QIcon
from client_database_module import ClientDatabaseWidget

try:
    sys.stdout.reconfigure(encoding='utf-8')
except:
    pass

class EyeTrackingMainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Eye Tracking and Disease Prediction")
        self.setGeometry(100, 100, 1200, 700)
        self.setStyleSheet("background-color: #e6f0fa;")
        self.setWindowIcon(QIcon("1.png"))

        self.selected_client_id = None
        self.selected_client_name = ""
        self.client_score = None

        eye_icon = QLabel()
        eye_icon.setPixmap(QPixmap("1.png").scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        eye_icon.setAlignment(Qt.AlignCenter)

        title_label = QLabel("EYE TRACKING AND DISEASE PREDICTION")
        title_label.setFont(QFont("Arial", 20, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("color: #123456; margin: 10px;")

        self.menu = QListWidget()
        self.menu.setFixedWidth(200)
        self.menu.addItems([
            "Dashboard",
            "Live Eye Tracking",
            "Gaze Heatmap",
            "Disease Prediction",
            "Add Client",
            "Data Collection"
        ])
        self.menu.currentRowChanged.connect(self.display_tab)

        self.stack = QStackedLayout()
        self.pages = []

        for name in self.menu.findItems("", Qt.MatchContains):
            label = QLabel(name.text())
            label.setAlignment(Qt.AlignCenter)
            label.setFont(QFont("Arial", 16))
            page_widget = QWidget()
            layout = QVBoxLayout()
            layout.addWidget(label)

            if name.text() == "Dashboard":
                collect_button = QPushButton("Collect Eye Data for New Client")
                collect_button.clicked.connect(self.collect_eye_data_for_client)
                layout.addWidget(collect_button)

            if name.text() == "Live Eye Tracking":
                run_button = QPushButton("Start Eye Tracking")
                run_button.clicked.connect(self.run_eye_tracking_script)
                layout.addWidget(run_button)

            if name.text() == "Gaze Heatmap":
                heatmap_label = QLabel()
                heatmap_pixmap = QPixmap("pupil_heatmap.png")
                if heatmap_pixmap.isNull():
                    heatmap_label.setText("Heatmap image not found.")
                else:
                    heatmap_label.setPixmap(heatmap_pixmap.scaled(800, 600, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                heatmap_label.setAlignment(Qt.AlignCenter)
                layout.addWidget(heatmap_label)

            if name.text() == "Disease Prediction":
                disease_label = QLabel("Select a disease to predict:")
                disease_label.setFont(QFont("Arial", 14))
                disease_label.setAlignment(Qt.AlignCenter)

                self.disease_combo = QComboBox()
                self.disease_combo.addItems(["Autism", "ADHD", "Alzheimer's", "Depression", "Parkinson's", "Anxiety"])
                self.disease_combo.setFixedWidth(200)
                self.disease_combo.setStyleSheet("margin: 10px auto;")

                predict_button = QPushButton("Start Prediction (Select Client First)")
                predict_button.clicked.connect(self.select_client_and_predict)

                layout.addWidget(disease_label)
                layout.addWidget(self.disease_combo, alignment=Qt.AlignCenter)
                layout.addWidget(predict_button)

            if name.text() == "Add Client":
                layout.addWidget(ClientDatabaseWidget())

            if name.text() == "Data Collection":
                layout.addWidget(QLabel("Step 1: Select Client"))
                self.select_client_btn = QPushButton("Select Client")
                self.select_client_btn.clicked.connect(self.select_client_for_data)
                layout.addWidget(self.select_client_btn)

                self.selected_client_label = QLabel("No client selected")
                self.selected_client_label.setStyleSheet("color: gray;")
                layout.addWidget(self.selected_client_label)

                layout.addWidget(QLabel("Step 2: Select Disorder Type"))
                self.collection_disease_combo = QComboBox()
                self.collection_disease_combo.addItems(["Autism", "ADHD", "Alzheimer's", "Depression", "Parkinson's", "Anxiety"])
                layout.addWidget(self.collection_disease_combo)

                layout.addWidget(QLabel("Step 3: Enter Score"))
                self.score_input_btn = QPushButton("Enter Test Score")
                self.score_input_btn.clicked.connect(self.enter_score_for_client)
                layout.addWidget(self.score_input_btn)

                layout.addWidget(QLabel("Step 4: Calibrate Screen and Record Eye Data"))
                self.run_collection_btn = QPushButton("Start Calibration and Data Recording")
                self.run_collection_btn.clicked.connect(self.run_calibration_and_collection)
                layout.addWidget(self.run_collection_btn)

            page_widget.setLayout(layout)
            self.pages.append(page_widget)
            self.stack.addWidget(page_widget)

        main_layout = QVBoxLayout()
        main_layout.addWidget(eye_icon)
        main_layout.addWidget(title_label)

        content_layout = QHBoxLayout()
        content_layout.addWidget(self.menu)

        content_widget = QWidget()
        content_widget.setLayout(self.stack)
        content_layout.addWidget(content_widget)

        main_layout.addLayout(content_layout)
        self.setLayout(main_layout)

    def display_tab(self, index):
        self.stack.setCurrentIndex(index)

    def run_eye_tracking_script(self):
        try:
            subprocess.Popen([sys.executable, "eye_tracking_and_heatmap.py"])
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to run eye tracking script.\n{e}")

    def select_client_and_predict(self):
        try:
            conn = sqlite3.connect("clients.db")
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM clients")
            clients = cursor.fetchall()
            conn.close()

            if not clients:
                QMessageBox.warning(self, "No Clients", "Please add a client first in 'Add Client' tab.")
                return

            items = [f"{id} - {name}" for id, name in clients]
            selected, ok = QInputDialog.getItem(self, "Select Client", "Choose a client to assign prediction:", items, 0, False)
            if ok and selected:
                client_id = int(selected.split(" - ")[0])
                disease = self.disease_combo.currentText()
                clean_name = disease.lower().replace("'", "").replace(" ", "_")
                script_name = f"predict_{clean_name}.py"

                subprocess.run([sys.executable, "screen_calibrator.py"], check=True)
                subprocess.Popen([sys.executable, script_name, str(client_id)])
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def collect_eye_data_for_client(self):
        try:
            conn = sqlite3.connect("clients.db")
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM clients")
            clients = cursor.fetchall()
            conn.close()

            if not clients:
                QMessageBox.warning(self, "No Clients", "Please add a client first in 'Add Client' tab.")
                return

            items = [f"{id} - {name}" for id, name in clients]
            selected, ok = QInputDialog.getItem(self, "Select Client", "Choose a client to collect eye data:", items, 0, False)
            if ok and selected:
                client_id = int(selected.split(" - ")[0])
                disease = self.collection_disease_combo.currentText()
                subprocess.run([sys.executable, "screen_calibrator.py"], check=True)
                subprocess.run([sys.executable, "record_eye_data.py", str(client_id), disease], check=True)
                QMessageBox.information(self, "Done", f"Eye data recorded for client ID {client_id}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to collect eye data.\n{e}")

    def select_client_for_data(self):
        try:
            conn = sqlite3.connect("clients.db")
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM clients")
            clients = cursor.fetchall()
            conn.close()

            if not clients:
                QMessageBox.warning(self, "No Clients", "Please add a client first.")
                return

            items = [f"{id} - {name}" for id, name in clients]
            selected, ok = QInputDialog.getItem(self, "Select Client", "Choose a client:", items, 0, False)
            if ok and selected:
                self.selected_client_id = int(selected.split(" - ")[0])
                self.selected_client_name = selected.split(" - ")[1]
                self.selected_client_label.setText(f"Selected: {self.selected_client_name} (ID: {self.selected_client_id})")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error selecting client: {e}")

    def enter_score_for_client(self):
        if self.selected_client_id is None:
            QMessageBox.warning(self, "No Client", "Please select a client first.")
            return

        score, ok = QInputDialog.getDouble(self, "Enter Score", "Enter test score:", 0, 0, 100, 1)
        if ok:
            self.client_score = score
            QMessageBox.information(self, "Score Recorded", f"Score {score} recorded for client {self.selected_client_name}.")

    def run_calibration_and_collection(self):
        if self.selected_client_id is None or self.client_score is None:
            QMessageBox.warning(self, "Incomplete Info", "Please select client and enter score before proceeding.")
            return

        try:
            subprocess.run([sys.executable, "screen_calibrator.py"], check=True)
            disease = self.collection_disease_combo.currentText()
            subprocess.run([sys.executable, "record_eye_data.py", str(self.selected_client_id), disease], check=True)
            QMessageBox.information(self, "Done", f"Data collection completed for client {self.selected_client_name}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed during calibration or data collection: {e}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = EyeTrackingMainWindow()
    win.show()
    sys.exit(app.exec_())